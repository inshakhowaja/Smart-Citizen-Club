setTimeout(function(){
    odometer.innerHTML = 10000;
}, 1000);
